package com.example.appmaskcycle.clases

interface InterfaceTiposMasc {
    
}