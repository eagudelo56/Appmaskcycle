package com.example.appmaskcycle.clases

class FactoriaTiposMasc {
}