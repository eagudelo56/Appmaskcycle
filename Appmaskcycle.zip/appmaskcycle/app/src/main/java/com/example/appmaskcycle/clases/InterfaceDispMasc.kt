package com.example.appmaskcycle.clases

interface InterfaceDispMasc {
    //**hola
}