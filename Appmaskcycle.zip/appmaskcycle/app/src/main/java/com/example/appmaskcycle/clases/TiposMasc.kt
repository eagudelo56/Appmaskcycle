package com.example.appmaskcycle.clases

class TiposMasc() {

}