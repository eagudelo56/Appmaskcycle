package com.example.appmaskcycle.clases

class DispMasc {
}