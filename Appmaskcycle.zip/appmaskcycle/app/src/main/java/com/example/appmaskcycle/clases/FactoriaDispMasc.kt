package com.example.appmaskcycle.clases

class FactoriaDispMasc {
}