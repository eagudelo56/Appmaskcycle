package com.example.appmaskcycle.clases

class FactoriaUsuarios {

    companion object{
        fun getUsuarioDao () : Usuarios{
            return Usuarios(-1,"", "")
        }

    }

}